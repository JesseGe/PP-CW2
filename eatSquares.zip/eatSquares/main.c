

#include <stdbool.h>
#include <SDL2/SDL.h>

#include "controlFunctions.h"

/*
 *   SDL game loop
 */

int main( void )
{
    int delay = 160;

    init();   // setup the game data
    render(); // render initial state

    while( true ) {      // game loop

        input();            // keyboard input

        if( !update() )     // update and ...
            gameover();         // check if finished

        render();           // render new state

        SDL_Delay( delay ); // time between frames (ms)
    }
    return 0;
}

