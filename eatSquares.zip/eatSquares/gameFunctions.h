
void next_square(void);

void draw_object( node object, SDL_Texture *texture );


