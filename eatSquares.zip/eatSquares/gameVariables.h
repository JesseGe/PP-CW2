
int dir;
bool eaten;
int number;

SDL_Renderer* renderer = NULL;

SDL_Surface*  white_surface = NULL;
SDL_Surface*  square_surface = NULL;
SDL_Surface*  circle_surface = NULL;

SDL_Texture*  white_texture = NULL;
SDL_Texture*  square_texture = NULL;
SDL_Texture*  circle_texture = NULL;

